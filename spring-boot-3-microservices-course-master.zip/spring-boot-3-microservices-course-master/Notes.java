package org.example;

public class Notes {
    public static void main(String[] args) {
        System.out.println("This is a placeholder for notes.");
    }
}

// NOTES

// Spring cloud provides tools for developers to quickly build some of the common patterns in distributed systems (e.g. configuration management, service discovery, circuit breakers, intelligent routing, micro-proxy, control bus). It is a framework that provides a set of tools for developers to quickly build some of the common patterns in distributed systems (e.g. configuration management, service discovery, circuit breakers, intelligent routing, micro-proxy, control bus, short lived microservices, and contract testing).

// In this project, we will have the following components:
// 1. Product Service: This service will act as a product catalog service. It will provide APIs to create and view products.
// 2. Order Service: to make orders for products
// 3. Inventory Service: to manage the inventory of products and check if a product is available in stock or not before making an order.
// 4. Notification Service: to send notifications to users when an order is placed.

// Here the order service, inventory service, and notification service will interact with each other to complete the order process. The product service will be a standalone service that provides product information to the order service. The order service will check with the inventory service to see if the product is available in stock before placing an order. If the product is available, the order service will place the order and notify the user through the notification service.
// We will use both async and sync communication here.

// The product service will be connected to mongodb.
// The order service will be connected to mysql because it will be a transactional service.
//  The inventory service will have its own mysql database to manage the inventory of products.
// The notification service is stateless and won't have any database.
// The order service will communicate with the inventory service through sync calls and with the notification service (will use kafka) through async calls.

// Besides these main components, we will have supporting components like API gateway, auth server (uses keycloak), eureka (for server discovery) and grafana (for observability).
// The API gateway will be connected to the product service, order service and the auth server.
// In grafana, we will use grafana loki to aggregate logs from all the services and view them, grafana tempo to trace the requests and view the traces, and grafana prometheus to monitor the services and view the metrics.

// Finally, we will use docker to containerize all the services and docker compose to run all the services together.
// We will also use kubernetes to deploy the services in a cluster and manage them.
// We will use helm charts to deploy the services in the kubernetes cluster.

// For each service, we will have a controller, service and repository layer.
// We will have message queue (kafka) in service layer of notification service and also in the order service.

// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// PRODUCT SERVICE

// We will use maven here and in spring initializr for product service, we will select the following dependencies:
// 1. Spring Web
// 2. Spring Data JPA (not for product service)
// 3. Spring Data MongoDB
// 4. Spring Boot DevTools
// 5. Lombok
// 6. Testcontainers (used to run tests with docker containers instead of mock objects so that we can test the services with real databases and message queues instead of mock objects)

// Testcontainers provide lightweight, throwaway instances of common databases, Selenium web browsers, or anything else that can run in a Docker container.

// We will use docker compose to download mongodb.

// Once we generate the zip file from spring initializr, we will extract it and open it in intellij idea.
// To check if all the downloads are successful, we will run 'mvn clean verify' command in the terminal.

// To get mongodb, we will first create docker-compose.yml in the service folder and add the following code to it:
// version: '4'
// services:
//   mongodb:
//     image: mongo:latest (or mongo:7.0.5)
//     container_name: mongodb
//     ports:
//       - "27017:27017" (first port is the port on the host machine and second port is the port on the container)
//     environment:
//       MONGO_INITDB_ROOT_USERNAME: root
//       MONGO_INITDB_ROOT_PASSWORD: password
//       MONGO_INITDB_DATABASE: product-service
//     volumes:
//       - ./data:/data/db (this will create a data folder in the service folder and mount it to the /data/db folder in the container so that the data is persisted even if the container is removed)
// Then we run 'docker compose up -d' command in the terminal to start the mongodb container in detached mode (runs in the background). We can check if the container is running by running 'docker ps' command in the terminal. We can also check the logs of the container by running 'docker logs mongodb' command in the terminal. We can stop the container by running 'docker compose down' command in the terminal.

// Then we can add 'spring.data.mongodb.uri=mongodb://root:password@localhost:27017/product-service' in the application.properties file to connect to the mongodb database.

// Then we create a directory structure for the product service as follows:
// src/main/java/org/example/productservice
// ├── controller
// │   └── ProductController.java
// ├── model
// │   └── Product.java
// ├── repository
// │   └── ProductRepository.java
// └── service
// │   └── ProductService.java
// ├── dto
// │   │── ProductRequest.java
// │   └── ProductResponse.java

// ProductRequest is the data the client sends to the API when creating a product. Product is the object the service stores in MongoDB.
// They currently have the same fields, but they serve different purposes:
// ProductRequest describes the API input; Product describes the stored data.
// Keeping them separate lets us change or validate the API input without changing the database model.
// It also lets us prevent clients from setting fields that should be controlled by the service, such as a database-generated ID.
// Similary we can also have a ProductResponse class to describe the API output. This is useful if we want to hide some fields from the client or add some additional fields to the response.

// Test containers is a Java library that supports JUnit tests, providing lightweight, throwaway instances of common databases, Selenium web browsers, or anything else that can run in a Docker container.
// We will use test containers to test the product service with a real mongodb database instead of a mock object by starting it in a docker container.

// We will use the io.rest-assured dependency to make HTTP requests to the product service API and verify the responses. We will add the following dependency to the pom.xml file:
// <dependency>
//     <groupId>io.rest-assured</groupId>
//     <artifactId>rest-assured</artifactId>
//     <version>5.3.2</version>
//     <scope>test</scope>
// </dependency>

// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// ORDER SERVICE

// Dependencies for order service:
// 1. Spring Web
// 2. Spring Data JPA
// 3. MySQL Driver
// 4. Spring Boot DevTools
// 5. Lombok
// 6. Testcontainers
// 7. Flyway Migration (Version control for database schema changes; gets flyway-sql and spring-boot-starter-flyway dependencies in pom.xml file)

// Flyway keeps track of changes to the database structure using numbered SQL files.
// For example, when we first create the order service, we could add this file in src/main/resources/db/migration:
//
// V1__create_orders.sql
// CREATE TABLE orders (
//     id BIGINT PRIMARY KEY,
//     order_number VARCHAR(255) NOT NULL
// );
//
// Later, if each order needs a status, we add a new file instead of changing V1:
// V2__add_order_status.sql
// ALTER TABLE orders ADD COLUMN status VARCHAR(50);
//
// When Flyway runs, it applies the files in order and records which ones have already run.
// A new database receives V1 and V2; a database that already has V1 receives only V2. This helps keep databases in different environments consistent.
// Will Flyway create the orders table every time the application starts? No.
// Flyway records successful migrations in the database's flyway_schema_history table.
// On later starts, it sees that V1 has already run and does not run it again.
// A new, empty database has no migration history, so Flyway runs V1 there.
// We will keep the flyway migration files in src/main/resources/db/migration folder. The files should be named in the format V<version>__<description>.sql. The version should be a number and the description should be a short description of the change. The version should be incremented for each new migration file. The description should be in lowercase and words should be separated by underscores. For example, V1__create_orders.sql, V2__add_order_status.sql, V3__add_order_date.sql, etc.

// We will run order service on port 8081 since product service is running on port 8080. We can change the port in application.properties file by adding 'server.port=8081'.

// We create a docker-compose.yml file for the order service to download mysql.
// version: '4'
// services:
//   mysql:
//     image: mysql:8.3.0
//     container_name: mysql
//     ports:
//       - "3306:3306" // Default for MySQL
//     environment:
//       MYSQL_ROOT_PASSWORD: password
//     volumes:
//       - ./data:/var/lib/mysql

// In application.properties, we add the following properties to connect to the mysql database:
// spring.datasource.url=jdbc:mysql://localhost:3306/order_service
// spring.datasource.username=root
// spring.datasource.password=password
// spring.jpa.hibernate.ddl-auto=none // setting to none because we are using flyway to manage the database schema changes

// We also need to initialize the database before running application by creating a database named 'order_service' in mysql. So we create a folder docker/mysql and add a file init.sql with the following content:
// CREATE DATABASE IF NOT EXISTS order_service;
// We will add this init.sql file to the docker-compose.yml file as a volume so that it is executed when the mysql container is started. We can do this by adding the following line to the mysql service in docker-compose.yml:
// volumes:
//   - ./data:/var/lib/mysql
//   - ./docker/mysql/init.sql:/docker-entrypoint-initdb.d/init.sql
// The docker-entrypoint command runs whenever a container is started. The init.sql file will be executed when the mysql container is started and it will create the database if it does not exist. We can check if the database is created by running 'docker exec -it mysql mysql -u root -p' command in the terminal to enter the mysql shell and then run 'show databases;' command to see the list of databases.
// The docker-entrypoint-initdb.d directory is a special directory in the mysql container that is used to initialize the database. Any .sql or .sh files in this directory will be executed when the container is started. This is useful for setting up the database schema and initial data.

// We will create a directory structure for the order service as follows:
// src/main/java/org/example/orderservice
// ├── controller
// │   └── OrderController.java
// ├── model
// │   └── Order.java
// ├── repository
// │   └── OrderRepository.java
// └── service
// │   └── OrderService.java
// └── dto
// │   ├── OrderRequest.java
// │   └── OrderResponse.java
// └── client
//     └── InventoryClient.java (for inter service communication with inventory service)

// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// INVENTORY SERVICE

// Dependencies for inventory service:
// 1. Spring Web
// 2. Spring Data JPA
// 3. MySQL Driver
// 4. Spring Boot DevTools
// 5. Lombok
// 6. Testcontainers
// 7. Flyway Migration

// We will run inventory service on port 8082 since product service is running on port 8080 and order service is running on port 8081. We can change the port in application.properties file by adding 'server.port=8082'.
// We will create a docker-compose.yml file for the inventory service to get mysql and run it on port 3307 since order service is running on port 3306. We can change the port in docker-compose.yml file by adding 'ports: - "3307:3306"' under mysql service. 3307 is the port on the host machine and 3306 is the port on the container.
// We will also make sure the inventory service container name is different from the order service container name. We can change the container name in docker-compose.yml file by adding 'container_name: inventory_mysql' under mysql service. This will make sure the container name is different from the order service container name which is 'mysql'.
// We will also create a folder docker/mysql and add a file init.sql with the following content:
// CREATE DATABASE IF NOT EXISTS inventory_service;
// We will add this init.sql file to the docker-compose.yml file as a volume so that it is executed when the mysql container is started. We can do this by adding the following line to the mysql service in docker-compose.yml:
// volumes:
//   - ./data:/var/lib/mysql
//   - ./docker/mysql/init.sql:/docker-entrypoint-initdb.d/init.sql

// In application.properties, we add the following properties to connect to the mysql database:
// spring.datasource.url=jdbc:mysql://localhost:3307/inventory_service
// spring.datasource.username=root
// spring.datasource.password=password
// spring.jpa.hibernate.ddl-auto=none

// We will also create v1__init.sql file in src/main/resources/db/migration folder for table creation and initial data insertion. The file will have the following content:
// V1__init.sql
// CREATE TABLE inventory (
//     id BIGINT PRIMARY KEY AUTO_INCREMENT,
//     sku_code VARCHAR(255) NOT NULL,
//     quantity INT NOT NULL
// );

// We also create v2__add_inventory.sql file in src/main/resources/db/migration folder for initial data insertion. The file will have the following content:
// V2__add_inventory.sql
// INSERT INTO inventory (sku_code, quantity)
// VALUES ('iphone_13', 100),
//        ('pixel_6', 50),
//       ('samsung_galaxy_s21', 75),
//      ('oppo_find_x3', 25),
//    ('vivo_y21', 10);

// We will create a directory structure for the inventory service as follows:
// src/main/java/org/example/inventoryservice
// ├── controller
// │   └── InventoryController.java
// ├── model
// │   └── Inventory.java
// ├── repository
// │   └── InventoryRepository.java
// └── service
// │   └── InventoryService.java

// --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// INTER-SERVICE COMMUNICATION AND TESTING WITH WIREMOCK

// Whenever a user places an order, we will make a HTTP sync call from order service to inventory server to check if the product is available in stock or not.
// We can use any of the rest clients like RestTemplate, WebClient, RestClient (latest in spring boot 3) to make the sync call.
// We will use Spring Cloud OpenFeign to make the call here. It is a declarative web service client that makes writing web service clients easier. It uses annotations to define the web service client and the methods to call the web service. It also integrates with Ribbon and Eureka to provide load balancing and service discovery. We will create a feign client interface in order service to call the inventory service API. The interface will have a method to check if the product is available in stock or not. The method will take the skuCode as a parameter and return a boolean value indicating if the product is available in stock or not. We will use this method in the order service to check if the product is available in stock or not before placing an order.
// We will add the dependency spring-cloud-starter-openfeign in the pom.xml file of order service to use OpenFeign.
// We will also add the spring-cloud-dependencies in the <dependencyManagement> section of the pom.xml file of order service to manage the versions of the spring cloud dependencies.

// Then we will create a feign client interface in order service to call the inventory service API.
// It will be in the package com.jaga.microservice.order.client and will be named InventoryClient.java.
// We will annotate the interface with @FeignClient(name = "inventory", url = "http://localhost:8082") to specify the name of the inventory service and the url of the inventory service.
// It will have a rest call method @GetMapping(value = "/api/inventory") boolean isInStock(@RequestParam String skuCode, @RequestParam Integer quantity); to check if the product is available in stock or not.

// We will use the InventoryClient in the OrderService to check if the product is available in stock or not before placing an order.

// But now, even our test methods will need to call the inventory service to check if the product is available in stock or not and this is not a good practice especially when we are using paid apis.
// So we will mock the call of the inventory client. We can do this in 2 ways:
// 1. A mocking library like Mockito to mock the call of the inventory client in the test methods of order service. We will use @MockBean annotation to mock the inventory client in the test class of order service. We will use when().thenReturn() method to specify the return value of the mocked method.
// 2. We can use WireMock to mock the inventory service API. We will create a WireMock server in the test class of order service and specify the response of the inventory service API. We will use @AutoConfigureWireMock annotation to configure the WireMock server in the test class of order service. We will use stubFor() method to specify the response of the inventory service API.
// WireMock is a better option than Mockito because it allows us to mock the entire API and not just the method. It also allows us to specify the response of the API based on the request parameters. It also allows us to verify if the API was called or not. It also allows us to simulate different scenarios like network latency, server errors, etc. It also allows us to record the requests and responses of the API for debugging purposes.

// WireMock normally returns a configured response without calling the real API.
// For example, configure the order service's inventory client to use the running
// WireMock server's URL during a test, then define the expected response:
//
// stubFor(get(urlPathEqualTo("/api/inventory"))
//     .withQueryParam("skuCode", equalTo("iphone_13"))
//     .withQueryParam("quantity", equalTo("1"))
//     .willReturn(aResponse()
//         .withStatus(200)
//         .withHeader("Content-Type", "application/json")
//         .withBody("true")));
//
// When the order service sends that request to WireMock, it receives true without
// contacting the real inventory service. We can also verify the request was made:
//
// verify(getRequestedFor(urlPathEqualTo("/api/inventory"))
//     .withQueryParam("skuCode", equalTo("iphone_13"))
//     .withQueryParam("quantity", equalTo("1")));
//
// WireMock can also be explicitly configured as a proxy to forward requests to a real API.

// To use wiremock, we will add the dependency spring-cloud-starter-contract-stub-runner in the pom.xml file of order service.
// The @AutoConfigurationWireMock annotation is used to configure the WireMock server in the test class of order service. We will use @AutoConfigurationWireMock(port = 0) to configure the WireMock server to run on a random port. We will use @LocalServerPort annotation to get the port number of the WireMock server. We will use @BeforeEach annotation to set up the WireMock server before each test method. We will use @AfterEach annotation to stop the WireMock server after each test method. We will use stubFor() method to specify the response of the inventory service API. We will use verify() method to verify if the API was called or not.
// Use @AutoConfigureWireMock on each test class that needs WireMock, unless those classes share it through a base class or a custom annotation.
// Besides the WireMock server (we get server using the autoconfiguration annotation above), we also need to add stubs (like the stubFor() method) to define the expected responses for the API calls. We will create a stubs direcitory in src/test/java/com/jaga/microservice/order and create stub classes there.

// For the wiremock port config, we will create resources/application.properties in test directory and add the property inventory.url=http://localhost:${wiremock.server.port}
// In the inventoryClient also, we will use the property inventory.url to configure the base URL of the inventory service by adding in src application.properties, so that it points to the WireMock server during tests.
// Spring boot will automatically inject the wiremock port in out application.properties file in test.

// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// API GATEWAY USING SPRING CLOUD GATEWAY MVC

// API gateway acts an an entry point for all requests to our service.
// We will forwared the requests to the appropriate service based on the request path. For example, if the request path is /api/product/**, we will forward the request to the product service. If the request path is /api/order/**, we will forward the request to the order service. If the request path is /api/inventory/**, we will forward the request to the inventory service.
// API gateway is commonly used the distributed systems and microservices architecture to provide a single entry point for all requests to the services.
// It also provides features like authentication, authorization, rate limiting, caching, logging, monitoring, etc.
// It also provides a way to route the requests to the appropriate service based on the request path, request method, request headers, request parameters, etc.
// It also provides a way to transform the requests and responses before forwarding them to the services.
// It also provides a way to handle errors and exceptions in a centralized way. It also provides a way to implement circuit breakers and fallback mechanisms for the services.
// It also provides a way to implement service discovery and load balancing for the services.
// It also provides a way to implement security for the services using OAuth2, JWT, etc.
// Disadvantages: increased complexity to maintain another component (API gateway), single point of failure (if the API gateway goes down, all requests to the services will fail), increased latency (since all requests have to go through the API gateway), increased cost (since we have to maintain another component), increased security risk (since the API gateway is exposed to the internet and can be attacked), increased development time (since we have to develop and maintain another component).
// We will use Spring Cloud Gateway MVC to implement the API gateway. We will create a new spring boot project for the API gateway and add the following dependencies:
// 1. Gateway
// 2. Spring Boot DevTools
// 3. Lombok

// In the api gateway project, we will define the routing routes in the routes package.
// We will use the functional endpoint routing design to route requests using functions instead of annotations. We will create a class Routes.java in the routes package and define the routes in it. We will use the RouterFunction and HandlerFunction classes to define the routes. We will use the RequestPredicate class to define the request predicates for the routes. We will use the ServerResponse class to define the responses for the routes. We will use the GatewayRouterFunctions class to define the routes using functional endpoints. We will use the GatewayHandlerFunction class to define the handler functions for the routes. We will use the GatewayRequestPredicate class to define the request predicates for the routes. We will use the GatewayServerResponse class to define the responses for the routes.

// We will then run the gateway service in port 9000.
// The rest calls will be made to url like http://localhost:9000/api/product/**, http://localhost:9000/api/order/**, http://localhost:9000/api/inventory/** and the gateway will forward the requests to the appropriate service based on the request path.

// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// SECURE MICROSERVICE WITH KEYCLOAK

// Keycloak is an open source IAM solution.
// It allows us to add auth to applications and secure services with minimum effort without having to store or authenticate users ourselves.
// It provides user federation, strong authentication, user management, fine-grained authorization, and more.
// It provides many features like SSO, Identity brokering and social login (logging in with social media accounts), User federation, Admin console, Account management console, Standard protocols, authorization services, and more.

// We will use it here to secure our api gateway.
// We will use docker-compose.yml to get keycloak in out gateway component. We will run both keycloak and a mysql db (to store keycloak metadata).
// version: '4'
// services:
//   keycloak-mysql:
//     image: mysql:8.3.0
//     container_name: keycloak-mysql
//     ports:
//       - "3308:3306" // Default for MySQL
//     environment:
//       MYSQL_ROOT_PASSWORD: rootpassword
//       MYSQL_DATABASE: keycloak
//       MYSQL_USER: keycloak
//       MYSQL_PASSWORD: password
//     volumes:
//       - ./volume-data/mysql-keycloak-data:/var/lib/mysql
//
//   keycloak:
//     image: quay.io/keycloak/keycloak:21.1.1
//     container_name: keycloak
//     command: ["start-dev", "--import-realm"]
//     environment:
//       DB_VENDOR: MYSQL
//       DB_ADDR: mysql
//       DB_DATABASE: keycloak
//       DB_USER: keycloak
//       DB_PASSWORD: password
//       KEYCLOAK_ADMIN: admin
//       KEYCLOAK_ADMIN_PASSWORD: admin
//     ports:
//       - "8181:8080"
//     volumes:
//       - ./docker/keycloak/realms/:/opt/keycloak/data/import
//     depends_on:
//       - keycloak-mysql

// Then we will run docker compose up -d to start both containers in detached mode.
// Then we can go to port 8181 in the browser and login to keycloak with username: admin and password: admin.
// Here we will have option to create realms. A realm is a container where you can have a set of users, clients, roles, groups and their configs in one place so that we can manage them easily in one place.
// So we can have one realm for one project and each realm is isolated from other realms.
// To create a realm, we will give it a name and resource file (optional, used to import realm config from a json file).

// Here we will create a realm 'spring-microservices-security-realm'.
// Then, in this realm, we can create our clients.

// Then we need to configure keycloak in our api gateway.
// We will add the dependencies in the pom.xml file of api gateway and enable oauth2 login.
// We can either have our application as a oauth2 client or oauth2 resource server.
// Oauth2 client means our application will be a client of keycloak and will redirect the user to keycloak login page for authentication and then get the access token from keycloak and use it to access the resources.
// Oauth2 resource server means our application will be a resource server and will validate the access token sent by the client in the request header and then allow or deny access to the resources based on the access token.
// Here we will use our api gateway as a oauth2 resource server and will validate the access token sent by the client in the request header and then allow or deny access to the resources based on the access token.
// Dependencies to add in pom.xml file of api gateway:
// 1. spring-boot-starter-oauth2-resource-server
// And in application.properties file of api gateway, we will add the following properties:
// spring.security.oauth2.resourceserver.jwt.issuer-uri=http://localhost:8181/realms/spring-microservices-security-realm (we can get uri in realm settings in keycloak)

// Then we will also add some security configs (SecurityFilterChain) in gateway/config/SecurityConfig.java file to secure the api gateway and allow only authenticated users to access the resources.

// Finally, to get a oauth token in postman, we specify the endpoint like GET http://localhost:9000/api/product and go to Authorization tab and select type OAuth 2.0 and set the access token url from the token_endpoint url in realm settings.
// Then we will give client id and client secret based on what we have in keycloak and click on Get New Access Token button to get the access token. We can then use this access token in the request header to access the resources in api gateway.

// After getting access token, it will automatically be added in authorization tab as access token and will be sent in the request header as Authorization: Bearer <access_token> to access the resources in api gateway. We can also manually add the access token in the request header as Authorization: Bearer <access_token> to access the resources in api gateway.
// Now calling the GET api/product endpoint would get us the product data.

// ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// DOCUMENTING REST API WITH OPEN API

// We will be using swagger as tool to document restapi. To use swagger, we will add the dependency springdoc-openapi-ui in the pom.xml file of each service and api gateway.
// We will also add the property springdoc.api-docs.path=/api-docs in the application.properties file of each service and api gateway to specify the path for the openapi documentation.
// We can then access the openapi documentation at http://localhost:<port>/api-docs and swagger ui at http://localhost:<port>/swagger-ui.html.
// We can also customize the openapi documentation by adding the properties springdoc.api-docs.title, springdoc.api-docs.description, springdoc.api-docs.version, springdoc.api-docs.contact.name, springdoc.api-docs.contact.email, springdoc.api-docs.contact.url, springdoc.api-docs.license.name, springdoc.api-docs.license.url in the application.properties file of each service and api gateway.

// Openapi is a specification for documenting REST APIs. It allows us to describe the structure of our APIs so that machines can read them. The OpenAPI Specification (OAS) defines a standard, language-agnostic interface to RESTful APIs which allows both humans and computers to discover and understand the capabilities of the service without access to source code, documentation, or through network traffic inspection.
// When properly defined via OpenAPI, a consumer can understand and interact with the remote service with a minimal amount of implementation logic.

// Besides letting us document our restapis, it also provides an auto-configuration feature to generate a swagger-ui.html page that allows us to test our restapis and generate documentation as json or yml or html.

// We can add a Config class to configure openapi and swagger.

// We can also use the dependency springdoc-openapi-starter-webmvc-api to generate openapi documentation for our restapis. It will automatically generate the openapi documentation based on the restapis defined in our service and api gateway. We can then access the openapi documentation at http://localhost:<port>/v3/api-docs and swagger ui at http://localhost:<port>/swagger-ui.html.

// ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// AGGREGATING RESTAPI DOCUMENTATION AND REFACTORING

// Here we will see how we can aggregate all openapi documentation from all services and api gateway into a single openapi documentation in the gateway.

// The difference between the dependencies springdoc-openapi-starter-webmvc-ui and springdoc-openapi-starter-webmvc-api is that the former includes the Swagger UI for visualizing and interacting with the API documentation, while the latter only generates the OpenAPI documentation without the UI.
// Besides the application.properties springdoc.swagger-ui.path and springdoc.api-docs.path, we can also add springdoc.swagger-ui.urls property in the application.properties file of api gateway to specify the urls of the openapi documentation of all services and api gateway.
// For example, springdoc.swagger-ui.urls[0].name=Product Service, springdoc.swagger-ui.urls[0].url=http://localhost:9000/product-service/api-docs, springdoc.swagger-ui.urls[1].name=Order Service, springdoc.swagger-ui.urls[1].url=http://localhost:9000/order-service/api-docs, springdoc.swagger-ui.urls[2].name=Inventory Service, springdoc.swagger-ui.urls[2].url=http://localhost:9000/inventory-service/api-docs, springdoc.swagger-ui.urls[3].name=API Gateway, springdoc.swagger-ui.urls[3].url=http://localhost:9000/api-gateway/api-docs
// We can then configure the routes in the api gateway to forward the requests to the appropriate service based on the request path. For example, if the request path is /product-service/api-docs, we will forward the request to http://localhost:8080/api-docs.
// Then in the security config, we will make changes to allow these urls with auth.

// Refactoring:
// Instead of open feign, we will use RestClient (in InventoryClient) because it is the latest in spring boot 3 and is more efficient than open feign.
// The spring framework provides the following choices for making calls to REST endpoints:
// 1. RestTemplate (synchronous client with template method API, blocking, deprecated in spring boot 3)
// 2. WebClient (asynchronous, non-blocking, supports reactive programming, recommended for spring boot 3) (requires webflux dependency)
// 3. RestClient (synchronous client, blocking, with a fluent API introduced in spring boot 3, more efficient than RestTemplate)
// 4. HTTP Interface (annotated interface with generated, dynamic proxy implementation, introduced in spring boot 3.1, recommended for spring boot 3.1 and above)

// We will use the http interface where we can define the rest calls similar to what is done in open feign.
// We will use this class using rest client for which we will have a config class to return InventoryClient created using HttpServiceProxyFactory which indirectly uses RestClient.
// We will also remove the @EnableFeignClients in the main application class.

// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// IMPLEMENTING CIRCUIT BREAKER USING RESILIENCE4J AND SPRING CLOUD CIRCUIT BREAKER

// Circuit breaker pattern is a general best practice used in distributed systems whenever our applications call some remote services.
// When the remote service we call is down or is taking too long to respond, that can degrade the performance of our service as well since we are waiting for its response.
// Similar to the curcuit breaker in electrical circuits, the circuit breaker pattern is used to detect failures and encapsulate the logic of preventing a failure from constantly recurring during maintenance, temporary external system failure or unexpected system difficulties.
// Whenever it finds a large number of calls to a service is failing, we will block all outgoing calls from our service to the failing service.

// We can implement circuit breaker pattern using Resilience4j library and Spring Cloud Circuit Breaker.
// Resilience4j is a lightweight fault tolerance library designed for functional programming. It provides higher-order functions (decorators) to enhance any functional interface, lambda expression or method reference with a Circuit Breaker, Rate Limiter, Retry or Bulkhead.
// The Spring Cloud Circuit Breaker project provides an abstraction over different circuit breaker implementations, like Resilience4j and Spring Retry, allowing developers to switch between implementations without changing their code.

// We will implement circuit breaker pattern wherever we are calling other services like in the order service and api gateway.
// We will add the dependency spring-cloud-starter-circuitbreaker-resilience4j in the pom.xml file of order service and api gateway to use Resilience4j and Spring Cloud Circuit Breaker.
// We will also add spring-cloud-starter-actuator dependency in the pom.xml file of order service and api gateway to expose the circuit breaker metrics and health endpoints.

// The we will configure the actuator and circuit breaker properties in the application.properties file of order service and api gateway.
// Actuator properties:
// management.health.circuitbreakers.enabled=true
// management.endpoints.web.exposure.include=* (like health, info, metrics, prometheus, circuitbreakers, etc.)
// management.endpoint.health.show-details=always
// Circuit breaker properties:
// resilience4j.circuitbreaker.configs.default.registerHealthIndicator=true // registers a health indicator for the circuit breaker in the actuator health endpoint
// resilience4j.circuitbreaker.configs.default.slidingWindowType=COUNT_BASED // The sliding window is used to record the outcome of calls when the circuit breaker is closed. The sliding window can be time-based or count-based. In a time-based sliding window, the circuit breaker records the outcome of calls over a fixed time period. In a count-based sliding window, the circuit breaker records the outcome of a fixed number of calls.
// resilience4j.circuitbreaker.configs.default.slidingWindowSize=10 // The sliding window size is the number of calls that are recorded in the sliding window. The circuit breaker uses the sliding window to calculate the failure rate and determine if the circuit breaker should be opened or closed.
// resilience4j.circuitbreaker.configs.default.failureRateThreshold=50 // The failure rate threshold is the percentage of failed calls that will cause the circuit breaker to open. If the failure rate exceeds this threshold, the circuit breaker will open and block all outgoing calls to the failing service.
// resilience4j.circuitbreaker.configs.default.waitDurationInOpenState=5s // The wait duration in open state is the time that the circuit breaker will stay open before transitioning to half-open state. In half-open state, the circuit breaker will allow a limited number of calls to the failing service to test if it is still failing or if it has recovered. If the calls are successful, the circuit breaker will close and allow all outgoing calls to the service. If the calls are still failing, the circuit breaker will open again and block all outgoing calls to the service.
// resilience4j.circuitbreaker.configs.default.permittedNumberOfCallsInHalfOpenState=3 // The permitted number of calls in half-open state is the number of calls that are allowed to the failing service when the circuit breaker is in half-open state. If the calls are successful, the circuit breaker will close and allow all outgoing calls to the service. If the calls are still failing, the circuit breaker will open again and block all outgoing calls to the service.
// resilience4j.circuitbreaker.configs.default.automaticTransitionFromOpenToHalfOpenEnabled=true // The automatic transition from open to half-open enabled property is used to automatically transition the circuit breaker from open state to half-open state after the wait duration in open state has elapsed. If this property is set to true, the circuit breaker will automatically transition to half-open state after the wait duration in open state has elapsed. If this property is set to false, the circuit breaker will remain in open state until it is manually transitioned to half-open state.
// resilience4j.circuitbreaker.configs.default.minimum-number-of-calls=5 // The minimum number of calls is the minimum number of calls that must be recorded in the sliding window before the circuit breaker can calculate the failure rate and determine if it should be opened or closed. If the number of calls in the sliding window is less than this value, the circuit breaker will not calculate the failure rate and will remain closed. If this property is not specified, the circuit breaker will calculate the failure rate and determine if it should be opened or closed based on the number of calls in the sliding window.
// Timeout properties:
// resilience4j.timelimiter.configs.default.timeout-duration=3s // The timeout duration is the maximum time that the circuit breaker will wait for a response from the failing service before considering the call as failed. If the call takes longer than this duration, the circuit breaker will consider the call as failed and increment the failure count in the sliding window. If the failure rate exceeds the failure rate threshold, the circuit breaker will open and block all outgoing calls to the failing service.
// Retry properties:
// resilience4j.retry.configs.default.max-attempts=3 // The max attempts is the maximum number of attempts that the circuit breaker will make to call the failing service before considering the call as failed. If the call fails after the maximum number of attempts, the circuit breaker will consider the call as failed and increment the failure count in the sliding window. If the failure rate exceeds the failure rate threshold, the circuit breaker will open and block all outgoing calls to the failing service.
// resilience4j.retry.configs.default.wait-duration=1s // The wait duration is the time that the circuit breaker will wait before making the next attempt to call the failing service. If the call fails after the maximum number of attempts, the circuit breaker will consider the call as failed and increment the failure count in the sliding window. If the failure rate exceeds the failure rate threshold, the circuit breaker will open and block all outgoing calls to the failing service.
// We will have all these resilience4j properties as resilience4j.*.instances.inventory.* instead of configs.default in order service to have different configurations for different circuit breakers.

// timeout-duration and wait-duration have different purposes:
// - resilience4j.timelimiter.configs.default.timeout-duration=3s limits how long one call may run before it times out.
// - resilience4j.retry.configs.default.wait-duration=1s is the delay after a failed attempt before Retry starts the next attempt.
// For example, if an attempt times out after 3 seconds, Retry waits 1 second before starting another attempt.
// These settings only affect calls when the corresponding TimeLimiter and Retry are actually applied to those calls.

// Then we will add configuration for the routes to include circuit breaker as a filter in api gateway.
// .filter(CircuitBreakerFilterFunctions.circuitBreaker("circuitBreakerName", URI.create("forward:/fallbackRoute"))) to add circuit breaker filter to the route and specify the fallback route to be called when the circuit breaker is open.

// In the order service inventory client, we will add @CircuitBreaker(name = "inventory", fallbackMethod = "fallbackMethod") to the method that calls the inventory service API to specify the circuit breaker name and the fallback method (which we will define) to be called when the circuit breaker is open.
// We will also add @Retry(name = "inventory") to the method that calls the inventory service API to specify the retry name.
// We can also add @TimeLimiter(name = "inventory") to the method that calls the inventory service API to specify the time limiter name. But this will complicate things as we will have to return a CompletableFuture from the method and also change the fallback method to return a CompletableFuture. So we will not use it here.
// Instead we will set a timeout for the rest client in the config class using getClientHttpRequestFactroy method to set the request factory with a timeout of 3 seconds. This will ensure that if the inventory service does not respond within 3 seconds, the call will be considered as failed and the circuit breaker will be triggered.

// -----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// EVENT DRIVEN ARCHITECTURE USING APACHE KAFKA (ALSO INCLUDES SCHEMA INTEGRATION)

// Apache Kafka is a distributed event-streaming platform used for event-driven applications and data pipelines.
// Services can communicate asynchronously by publishing events to Kafka topics; they can also use synchronous HTTP calls where appropriate.
// An event is a record of something that happened. For example, after an order is placed, the order service can publish an OrderPlaced event for the notification service to consume.
// Kafka retains events according to each topic's retention settings. Retention is configurable; Kafka does not guarantee permanent storage by default.
// Kafka can be configured for high availability and fault tolerance with multiple brokers and suitable replication. The single-broker example below is for local development and is not highly available.

// Spring for Apache Kafka provides KafkaTemplate for publishing, @KafkaListener and listener containers for consuming, KafkaAdmin for topic administration, and testing support in spring-kafka-test. KafkaProducer and KafkaConsumer are from the Apache Kafka client library.
// We will use Kafka to send asynchronous messages from the order service to the notification service.
// The following local-development example uses ZooKeeper with Confluent Kafka 7.5.0. Newer Kafka deployments can use KRaft instead of ZooKeeper.
// If the order and notification services run in Docker on the same Compose network, both should connect to kafka:29092. A client running directly on the host should connect to localhost:9092.
// Add this to docker-compose.yml file of order service:
// services:
//   zookeeper:
//     image: confluentinc/cp-zookeeper:7.5.0
//     container_name: zookeeper
//     hostname: zookeeper
//     ports:
//       - "2181:2181"
//     environment:
//       ZOOKEEPER_CLIENT_PORT: 2181 // Used by Kafka brokers to connect to Zookeeper
//       ZOOKEEPER_TICK_TIME: 2000 // The length of a single tick, which is the basic unit of time in Zookeeper. It is used to determine the timeout for various operations in Zookeeper. Here we are setting it to 2000 milliseconds (2 seconds).
//       ZOOKEEPER_SYNC_LIMIT: 2 // The maximum number of ticks that can pass between sending a request and receiving an acknowledgment from a follower. It is used to determine the timeout for various operations in Zookeeper. Here we are setting it to 2 ticks (4 seconds).
//   kafka:
//     image: confluentinc/cp-kafka:7.5.0
//     container_name: broker
//     ports:
//       - "9092:9092"
//       - "29092:29092" // We have 2 ports here because we will use 9092 for the notification service to connect to kafka and 29092 for the order service to connect to kafka.
//     depends_on:
//       - zookeeper // because before we run kafka, it needs to be connected to zookeeper. So we are specifying that kafka depends on zookeeper and will wait for zookeeper to be up and running before starting kafka.
//     environment:
//       KAFKA_BROKER_ID: 1 // The unique identifier for the Kafka broker. It is used to identify the broker in the Kafka cluster. Here we are setting it to 1.
//       KAFKA_ZOOKEEPER_CONNECT: zookeeper:2181 // The address of the Zookeeper instance that the Kafka broker will connect to. Here we are setting it to zookeeper:2181, which is the hostname and port of the Zookeeper container we defined above.
//       KAFKA_LISTENER_SECURITY_PROTOCOL_MAP: PLAINTEXT:PLAINTEXT,PLAINTEXT_HOST:PLAINTEXT // The security protocol to use for the listeners.
//       KAFKA_ADVERTISED_LISTENERS: PLAINTEXT://broker:29092,PLAINTEXT_HOST://localhost:9092 // The advertised listeners are the addresses that the Kafka broker will advertise to clients. Here we are setting it to broker:29092 for the order service to connect to kafka and localhost:9092 for the notification service to connect to kafka.
//       KAFKA_OFFSETS_TOPIC_REPLICATION_FACTOR: 1 // The replication factor for the offsets topic. It is used to determine how many copies of the offsets topic will be created in the Kafka cluster. Here we are setting it to 1, which means that there will be only one copy of the offsets topic in the Kafka cluster.
//   kafka-ui: // Used to view the kafka topics and messages in a web UI. We can use it to view the messages sent from order service to notification service.
//     image: provectuslabs/kafka-ui:latest
//     container_name: kafka-ui
//     ports:
//       - "8086:8080"
//     depends_on:
//       - broker
//     environment:
//       KAFKA_CLUSTERS_NAME: local
//       KAFKA_CLUSTERS_BOOTSTRAPSERVERS: broker:29092
//       DYNAMIC_CONFIG_ENABLED: 'true' // For dynamic configuration of Kafka clusters in the UI. It allows us to add, remove and update Kafka clusters in the UI without restarting the UI container.

// Then we can add the Spring for Apache Kafka dependencies (spring-kafka, spring-kafka-test, kafka (from testcontainers)) in the pom.xml file of order service and notification service to use KafkaTemplate, @KafkaListener, etc.
// Then we can add the Kafka configuration properties in the application.properties file of order service and notification service to configure the Kafka producer and consumer.
// Properties:
// spring.kafka.bootstrap-servers=localhost:9092 (for notification service) and spring.kafka.bootstrap-servers=localhost:29092 (for order service) to specify the Kafka broker address.
// spring.kafka.template.default-topic=order-placed to specify the default topic for the Kafka producer.
// spring.kafka.producer.key-serializer=org.apache.kafka.common.serialization.StringSerializer to specify the key serializer for the Kafka producer.
// spring.kafka.producer.value-serializer=org.apache.kafka.common.serialization.JsonSerializer to specify the value serializer for the Kafka producer.

// Then we write logic to send messages to kafka topic in order service and use in our service class to send messages to kafka topic when an order is placed.
// We will create a event package with OrderPlacedEvent class to represent the event and we will create an object of this class once we place an order in service class.
// Then we will use KafkaTemplate to send the event to kafka topic in the service class.

// To view in kafka ui, we go to localhost:8086 and configure new cluster with name: localhost, bootstrap servers: broker:29092, and click on add cluster. Then we can go to topics and click on order-placed topic to view the messages sent from order service to notification service.

// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// NOTIFICATION SERVICE

// Add these dependencies:
// 1. Lombok
// 2. Spring Boot DevTools
// 3. Spring for Apache Kafka
// 4. Testcontainers
// 5. Java mail sender (spring-boot-starter-mail) to send email notifications
// 6. Spring web (for json serialization and deserialization)

// Example Kafka consumer properties (these have not yet been added to notification-service/application.properties):
// spring.kafka.bootstrap-servers=localhost:9092
// spring.kafka.consumer.group-id=notificationService
// spring.kafka.consumer.key-deserializer=org.apache.kafka.common.serialization.StringDeserializer
// spring.kafka.consumer.value-deserializer=org.apache.kafka.common.serialization.JsonDeserializer
// spring.kafka.consumer.properties.spring.json.type.mapping=event:com.jaga.microservice.notification.event.OrderPlacedEvent // For deserializing the event into the notification service's OrderPlacedEvent class.

// HOW THE NOTIFICATION SERVICE SENDS EMAIL
// 1. The order service publishes an OrderPlacedEvent containing an order number and the customer's email address to the order-placed Kafka topic.
// 2. NotificationService listens to that topic with @KafkaListener. Kafka must be configured to deserialize the event into the notification service's OrderPlacedEvent class.
// 3. Spring injects JavaMailSender into NotificationService through the Lombok-generated constructor. The spring-boot-starter-mail dependency supplies the mail support.
// 4. A MimeMessagePreparator creates the email, and MimeMessageHelper sets its sender, recipient, subject and text. JavaMailSender.send then sends it through the configured SMTP server.
// 5. The listener logs a successful send; on a MailException it logs the error and throws an exception. Actual retry and recovery behavior depends on the Kafka listener's error-handler configuration.
//
// For example, the message preparation and send can be written as:
// MimeMessagePreparator preparator = mimeMessage -> {
//     MimeMessageHelper helper = new MimeMessageHelper(mimeMessage);
//     helper.setFrom("sender@example.com");
//     helper.setTo(message.getEmail());
//     helper.setSubject("Your order %s was placed".formatted(message.getOrderNumber()));
//     helper.setText("Your order with order number %s was placed successfully.".formatted(message.getOrderNumber()));
// };
// javaMailSender.send(preparator);
//
// These types are org.springframework.mail.javamail.MimeMessagePreparator, MimeMessageHelper and JavaMailSender.
// Configure an SMTP provider in application.properties, for example:
// spring.mail.host=${MAIL_HOST}
// spring.mail.port=${MAIL_PORT}
// spring.mail.username=${MAIL_USERNAME}
// spring.mail.password=${MAIL_PASSWORD}

// We can use mailtrap to test email sending in development. It provides a fake SMTP server that captures emails sent to it and allows us to view them in a web interface. We can sign up for a free account, create an inbox, and get the SMTP credentials (host, port, username, password) to use in our application.properties file.

// The OrderPlacedEvent class should be inside event package because if it isn't inside event package, then the notification service will not be able to deserialize the event into its own OrderPlacedEvent class because it will not be able to find the class in the event package. So we need to have the same package structure in both order service and notification service for the OrderPlacedEvent class.

// -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// SCHEMA INTEGRATION AND SCHEMA REGISTRY

// In the above scenario we see that we are having OrderPlacedEvent class in 2 places. Similarly, if we have multiple producers and consumers, we will have to replicate it in many places. This is inefficient.
// So we can use kafka schema registry to have a single source of truth for the schema of the events. The producer will register the schema of the event with the schema registry and the consumer will fetch the schema from the schema registry to deserialize the event.

// Schema registry provides a centralized repository for managing and validating schemas for topic message data and for serialization and deserialization of data over the network.
// Producers and consumers to kafka topics can use schemas to ensure data consistency and compatibility as schemas evolve.

// To run schema registry, we add this in the docker-compose.yml file of order service:
//   schema-registry:
//     image: confluentinc/cp-schema-registry:7.5.0
//     container_name: schema-registry
//     hostname: schema-registry
//     depends_on:
//       - broker
//     ports:
//       - "8085:8081"
//     environment:
//       SCHEMA_REGISTRY_HOST_NAME: schema-registry
//       SCHEMA_REGISTRY_KAFKASTORE_BOOTSTRAP_SERVERS: 'broker:29092'
//       SCHEMA_REGISTRY_LISTENERS: http://schema-registry:8081 // This means that the schema registry will listen on port 8081 for incoming requests. The schema registry will be accessible at http://localhost:8085 from the host machine and at http://schema-registry:8081 from other containers in the same Docker network.

// We can now delete the OrderPlacedEvent class from the order service and notification service and use the schema registry to manage the schema of the event.
// A communication format like Avro, Protobuf or JSON Schema is used to define the schema of the event. The producer will serialize the event using the schema and send it to the kafka topic. The consumer will fetch the schema from the schema registry and deserialize the event using the schema.
// We will create a avro directory in resources directory and create a file here 'order-placed.avsc' to define the schema of the event in both order service and notification service. The schema will have the fields orderNumber and email.
// order-placesd.avsc file content:
// {
//   "type": "record",
//   "name": "OrderPlacedEvent",
//   "namespace": "com.jaga.microservice.order.event", // This is the package name of the OrderPlacedEvent class in the order service. The consumer will use this package name to deserialize the event into its own OrderPlacedEvent class. So we need to have the same package name in both order service and notification service for the OrderPlacedEvent class.
//   "fields": [
//     {"name": "orderNumber", "type": "string"},
//     {"name": "email", "type": "string", "logicalType": "email", "doc": "The email address of the customer who placed the order."}
//   ]
// }

// AVRO SCHEMA AS THE SOURCE OF TRUTH
// Where is the single source of truth if we use .avsc files instead of handwritten event classes?
// The .avsc file defines the event contract; the Java OrderPlacedEvent class is generated from it by avro-maven-plugin and should not be edited manually.
// We still use a Java class in our service code; it is generated from the schema rather than maintained by hand.
// In the current setup, both services contain a copy of the schema and generate their own class. These copies can drift, so there is no single maintained source of truth across the services.
// A better approach is to maintain the schema once in a shared event-contracts project and publish a versioned JAR containing the generated Avro classes.
// Both services can depend on that JAR without depending on each other's service implementation. Each service can explicitly choose when to upgrade its contract version.
// Schema Registry stores versioned schemas used for Kafka serialization/deserialization and enforces the configured compatibility rules; it does not automatically synchronize local .avsc files.
// The Avro namespace determines the generated Java package. Notification service's com.jaga.microservice.order.event.OrderPlacedEvent import currently refers to its own locally generated class, not a dependency on order service.
// A neutral shared namespace such as com.jaga.microservice.events would make ownership clearer.
// In short: maintain the schema once, generate the Java classes from it, and distribute the versioned contract to both services.

// We also add the dependencies:
// 1. kafka-avro-serializer to serialize and deserialize the event using Avro format.
// 2. kafka-schema-registry-client to interact with the schema registry to register and fetch the schema of the event.
// 3. avro to generate the OrderPlacedEvent class from the order-placed.avsc file.

// And in plugins in pom.xml file of order service and notification service, we add the avro-maven-plugin to generate the OrderPlacedEvent class from the order-placed.avsc file.
// <plugin>
//   <groupId>org.apache.avro</groupId>
//   <artifactId>avro-maven-plugin</artifactId>
//   <version>1.11.3</version>
//   <executions>
//     <execution>
//       <id>schemas</id>
//       <phase>generate-sources</phase>
//       <goals>
//         <goal>schema</goal>
//       </goals>
//       <configuration>
//         <sourceDirectory>${project.basedir}/src/main/resources/avro</sourceDirectory>
//         <outputDirectory>${project.basedir}/src/main/java</outputDirectory>
//       </configuration>
//     </execution>
//   </executions>
// </plugin>

// We will also change the value serializer and deserializer in the application.properties file of order service and notification service to use the kafka-avro-serializer and kafka-avro-deserializer respectively.
// spring.kafka.producer.value-serializer=io.confluent.kafka.serializers.KafkaAvroSerializer
// spring.kafka.consumer.value-deserializer=io.confluent.kafka.serializers.KafkaAvroDeserializer

// We also add the schema registry url in application.properties file of order service and notification service to specify the url of the schema registry.
// spring.kafka.producer.properties.schema.registry.url=http://127.0.0.1:8085
// spring.kafka.consumer.properties.schema.registry.url=http://127.0.0.1:8085

// We will also add the property spring.kafka.consumer.properties.specific.avro.reader=true in the application.properties file of notification service to specify that we want to use the specific Avro reader to deserialize the event into the OrderPlacedEvent class generated from the order-placed.avsc file. This will ensure that the consumer will use the specific Avro reader to deserialize the event into its own OrderPlacedEvent class generated from the order-placed.avsc file instead of using the generic Avro reader which will deserialize the event into a GenericRecord object.
// We don't add this in producer because the producer will use the specific Avro writer to serialize the event into the OrderPlacedEvent class generated from the order-placed.avsc file by default.

// Sharing the event schema through a versioned JAR is a better approach than maintaining separate copies in each service. It ensures that both services use the same schema and can evolve independently while maintaining compatibility. The schema registry enforces compatibility rules and provides a centralized repository for managing schemas, but it does not synchronize local schemas or distribute the JAR.
// Maintain the .avsc schema once in an event-contracts project, generate the Java classes, and publish them as a versioned JAR.
// Both services depend on this JAR instead of maintaining separate schema copies or depending on each other's implementation.
// Schema Registry stores schemas and checks configured compatibility; it does not synchronize local schemas or distribute the JAR.

// We changed the names of the orderPlacedEvent classes we originally generated to LegacyOrderPlacedEvents so they don't cause conflict with the once that we will generate using the avro files in target\generated-sources\

// ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

// DEPLOYMENT

// Link for github repo: https://github.com/SaiUpadhyayula/spring-boot-3-microservices-course
// If you see here we would have put all our services in a single repo. But in real world we would have each service in a separate repo.
// This repo has a docker directory which would have files required to run in the docker container like init.sql, keyclock realm file etc.
// It also has a docker-compose.yml file to run all the services in docker containers.

// We have 2 ways to create docker images here:
// 1. Using dockerfile in each service.
// 2. Using cloud native buildpacks which is the recommended way to create docker images in spring boot 3.1 and above. We will use this approach here.

// Cloud native buildpacks is a tool that can create docker images from source code without the need for a dockerfile. It uses a set of buildpacks to detect the type of application and create a docker image with the necessary dependencies and configurations. It is the recommended way to create docker images in spring boot 3.1 and above because it is easier to use and maintain than using a dockerfile. It also creates smaller and more secure images than using a dockerfile.
// We will use the spring-boot-maven-plugin to create docker images using cloud native buildpacks in pom.xml.
// Code:
// <plugin>
//     <groupId>org.springframework.boot</groupId>
//     <artifactId>spring-boot-maven-plugin</artifactId>
//     <version>3.1.2</version>
//     <configuration>
//         <excludes>
//             <exclude>
//                 <groupId>org.projectlombok</groupId>
//                 <artifactId>lombok</artifactId>
//             </exclude>
//         </excludes>
//     </configuration>
// </plugin>

// We will now have a tool in the maven plugins > spring-boot > spring-boot-build-image to create docker images for each service in that repo.
// By default, we will use the builder-jammy-base builder image to create docker images. It is a buildpack builder image that uses Ubuntu Jammy as the base image and includes the necessary buildpacks to create docker images for spring boot applications. It is a good choice for creating docker images for spring boot applications because it is lightweight, secure and optimized for spring boot applications.
// If we want to use a different builder image, we can specify it in the configuration of the spring-boot-maven-plugin in pom.xml. For example, we can use the builder-image-builder image to create docker images for spring boot applications. It is a buildpack builder image that uses Ubuntu Focal as the base image and includes the necessary buildpacks to create docker images for spring boot applications. It is a good choice for creating docker images for spring boot applications because it is lightweight, secure and optimized for spring boot applications.
// Code: (add image in configuration for spring-boot-maven-plugin in pom.xml)
//     <configuration>
//         <image>
//             <builder>paketobuildpacks/builder:base</builder>
//         </image>
//     </configuration>

// We can also specify the name of the docker image to be created in the configuration of the spring-boot-maven-plugin in pom.xml.
// Code: (add name in image in configuration for spring-boot-maven-plugin in pom.xml)
//     <configuration>
//         <image>
//             <name><your-dockerhub-username>/${project.artifactId}:${project.version}</name> // We can also hardcode a value instead of getting artifactId and version
//             <publish>true</publish> // This will push the docker image to dockerhub after it is created. We can also set it to false or remove it if we don't want to push the docker image to dockerhub.
//         </image>
//     </configuration>

// If we set publish as trye above, we also need to add dockerhub creds here in pom.xml or settings.xml file of maven. We can add it in settings.xml file of maven in .m2 directory. We can also add it in pom.xml file of each service but it is not recommended because it will be visible to everyone who has access to the repo.
// Code: (add in pom.xml)
//     <configuration>
//         <image>
//             <name><your-dockerhub-username>/${project.artifactId}:${project.version}</name>
//             <publish>true</publish>
//         </image>
//         <docker>
//             <publishRegistry>
//                 <username>${env.DOCKER_USERNAME}</username>
//                 <password>${env.DOCKER_PASSWORD}</password>
//                 <url>https://index.docker.io/v1/</url>
//             </publishRegistry>
//         </docker>
//     </configuration>

// We can also run the command 'mvn spring-boot:build-image' in the terminal to create docker images for each service. This will create a docker image for each service and push it to dockerhub if publish is set to true in pom.xml file of each service.

// Once image is built and pushed to dockerHub, we need to create a kubernetes cluster to deploy the services. We can use kind (Kubernetes in Docker) to create a local kubernetes cluster.
// We need a local k8s cluster because we will use it to deploy our services in k8s cluster and test it locally before deploying it to a cloud provider like AWS, GCP, Azure etc.
// We can also used docker-desktop to create a local k8s cluster but it is not recommended because it is not lightweight and it takes a lot of resources.
// We need to have go and docker installed in our machine to install kind. We can install kind using the command 'go install sigs.k8s.io/kind@v0.23.0 && kind create cluster' in the terminal. This will install kind in our machine and we can use it to create a local k8s cluster.


// SIMPLER DEPLOYMENT APPROACH
// Kubernetes is optional: for local development we can use Docker Compose to run our services and infrastructure together.
// For production, a managed container platform can be simpler than operating a Kubernetes cluster ourselves.
// These are deployment options to implement; the notes below do not mean this project already has a complete Compose deployment.
//
// LOCAL DEVELOPMENT WITH DOCKER COMPOSE
// 1. Create a Docker image for each Spring Boot service, using a Dockerfile or Spring Boot buildpacks.
//    Compose can build Dockerfiles with a build: section. Images created separately with buildpacks can be referenced with image:.
// 2. Define product-service, order-service, inventory-service, notification-service and api-gateway in a root compose.yml.
//    Also define the infrastructure they need, such as MongoDB, MySQL, Kafka and Keycloak. Add SMTP test infrastructure or configure an SMTP provider for notification emails.
// 3. Compose creates a shared network by default. Containers reach each other using Compose service names, not localhost.
//    For example, from order-service use http://inventory-service:8082, not http://localhost:8082.
//    Kafka clients in containers need an internal advertised listener such as kafka:29092; host clients need a host-reachable listener such as localhost:9092.
//    Configure the broker's listeners and advertised listeners consistently with those addresses.
// 4. Set container-specific URLs, ports and credentials through environment variables in Compose or an external environment file.
//    Spring Boot maps environment variables to configuration properties; use the names supported by the application's configuration.
//    Keep passwords and tokens out of committed files. For production, use the platform's secret manager instead of relying on a local .env file.
// 5. Mount named volumes for data that must persist, especially MongoDB and MySQL. A container restart should not erase database data.
//    Backups are still needed: a volume alone is not a backup. Initialize databases and migrations deliberately.
// 6. Add health checks for dependencies and configure startup ordering where supported. depends_on alone does not mean a service is ready.
//    Applications should also retry transient connection failures; health checks cannot guarantee a dependency stays available later.
// 7. Publish only the ports needed on the host. For example, expose the gateway for API access; containers can use internal service ports without publishing them.
// 8. Put optional development tools such as Kafka UI or the Grafana stack in Compose profiles so they are not started by default.
//    From the directory containing compose.yml, use:
//    docker compose up --build        # Build configured Dockerfiles and start the default services.
//    docker compose --profile observability up --build # Also start services assigned to this profile.
//    docker compose logs -f           # Follow logs.
//    docker compose down              # Stop and remove containers and network; named volumes remain unless explicitly removed.
//
// SCHEMA REGISTRY
// The current KafkaAvroSerializer and KafkaAvroDeserializer require a reachable Confluent-compatible Schema Registry at runtime.
// We do not have to run a local registry container if we configure an external registry accessible to both services.
// Alternatively, choose and implement a different serialization approach; merely removing the registry container does not make the current Avro setup work.
// Building and compiling the services does not require the Schema Registry server to be running.
//
// PRODUCTION WITH A MANAGED CONTAINER PLATFORM
// 1. Build versioned images in CI, run checks, and publish the images to a container registry.
// 2. Deploy each image as a service on a managed platform and configure environment-specific URLs, secrets, CPU/memory, health checks and scaling.
// 3. Use managed databases and messaging where appropriate; configure persistent storage, backups, networking and access controls.
// 4. Expose the gateway through HTTPS, restrict internal services, and configure authentication, monitoring, logs and alerts.
// 5. Run schema/database migrations safely and use rolling deployments with a rollback plan.
// Use Kubernetes when its orchestration features justify the additional configuration and operational complexity.
