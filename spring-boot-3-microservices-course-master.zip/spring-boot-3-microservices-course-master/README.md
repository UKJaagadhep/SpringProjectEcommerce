# Spring Boot Microservices

## Run with Docker Compose

Requirements: Docker with the Compose plugin.

From the repository root:

```shell
cp .env.example .env
docker compose up --build -d
docker compose logs -f
```

Open the gateway Swagger UI at <http://localhost:9000/swagger-ui.html>. Keycloak is
at <http://localhost:8181> (`admin` / `localdev` by default). Compose runs the four
services, API gateway, databases, Kafka, Schema Registry, Keycloak and local SMTP
testing. Backend services and databases communicate over the private Compose network.

Stop containers with `docker compose down`. Named database volumes persist; remove
them with `docker compose down --volumes` only if you intend to delete the data.

The sample credentials and Keycloak development mode are for local use only. Set
strong passwords in `.env` before exposing services outside your machine.

## Build and test

```shell
mvn verify
```
