package com.jaga.microservice.order;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.Import;

import static org.hamcrest.Matchers.equalTo;

@Import(TestcontainersConfiguration.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureWireMock(port = 0)
class OrderServiceApplicationTests {

	@LocalServerPort
	private int port;

	@Test
	void contextLoads() {
	}

	@Test
	void shouldPlaceOrder() {
		String requestBody = """
				{
				    "orderNumber": "order-123",
				    "skuCode": "sku-123",
				    "price": 19.99,
				    "quantity": 2
				}
				""";

		InventoryClientStub.stubInventoryCall("sku-123", 2);

		RestAssured.given()
				.baseUri("http://localhost")
				.port(port)
				.contentType(ContentType.JSON)
				.body(requestBody)
				.when()
				.post("/api/order")
				.then()
				.statusCode(201)
				.body("orderNumber", equalTo("order-123"))
				.body("skuCode", equalTo("sku-123"))
				.body("price", equalTo(19.99f))
				.body("quantity", equalTo(2));

	}
}
