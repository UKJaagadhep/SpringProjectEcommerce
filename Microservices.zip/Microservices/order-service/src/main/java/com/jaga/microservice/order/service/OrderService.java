package com.jaga.microservice.order.service;

import com.jaga.microservice.order.dto.OrderRequest;
import com.jaga.microservice.order.dto.OrderResponse;
import com.jaga.microservice.order.model.Order;
import com.jaga.microservice.order.repository.OrderRepository;
import com.jaga.microservice.order.client.InventoryClient;
import com.jaga.microservice.order.event.OrderPlacedEvent;
import org.springframework.stereotype.Service;
import org.springframework.kafka.core.KafkaTemplate;
import lombok.RequiredArgsConstructor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
@RequiredArgsConstructor
public class OrderService {
    private final OrderRepository orderRepository;
    private final InventoryClient inventoryClient;
    private final KafkaTemplate<String, OrderPlacedEvent> kafkaTemplate; // String is the key type (usually topic name) and OrderPlacedEvent is the value type for the Kafka message

    Logger log = LoggerFactory.getLogger(OrderService.class);

    public OrderResponse placeOrder(OrderRequest orderRequest) {
        boolean isInStock = inventoryClient.isInStock(orderRequest.skuCode(), orderRequest.quantity());
        if (!isInStock) {
            throw new RuntimeException("Product with SKU code " + orderRequest.skuCode() + " is not in stock.");
        }
        Order order = Order.builder()
                .orderNumber(orderRequest.orderNumber())
                .skuCode(orderRequest.skuCode())
                .price(orderRequest.price())
                .quantity(orderRequest.quantity())
                .build();
        Order savedOrder = orderRepository.save(order);
        OrderPlacedEvent orderPlacedEvent = new OrderPlacedEvent();
        orderPlacedEvent.setOrderNumber(savedOrder.getOrderNumber());
        orderPlacedEvent.setEmail(orderRequest.userDetails().email());
        log.info("Starting to send OrderPlacedEvent to Kafka topic: {}", orderPlacedEvent);
        kafkaTemplate.send("order-placed", orderPlacedEvent);
        log.info("End of OrderPlacedEvent sent to Kafka topic successfully: {}", orderPlacedEvent);
        return new OrderResponse(savedOrder.getOrderNumber(), savedOrder.getSkuCode(), savedOrder.getPrice(), savedOrder.getQuantity());
    }
}