package com.jaga.microservice.order.event;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class LegacyOrderPlacedEvent {
    private String orderNumber;
    private String email;
}