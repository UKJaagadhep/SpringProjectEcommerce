package com.jaga.microservice.gateway.routes;

import java.net.URI;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Bean;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.ServerResponse;
import org.springframework.cloud.gateway.server.mvc.filter.CircuitBreakerFilterFunctions;
import org.springframework.cloud.gateway.server.mvc.handler.GatewayRouterFunctions;
import org.springframework.cloud.gateway.server.mvc.handler.HandlerFunctions;
import org.springframework.web.servlet.function.RequestPredicates;
import org.springframework.http.HttpStatus;

import static org.springframework.cloud.gateway.server.mvc.filter.BeforeFilterFunctions.setPath;
import static org.springframework.cloud.gateway.server.mvc.filter.BeforeFilterFunctions.uri;

@Configuration
public class Routes {

    /**
     * This method defines the routing for the product service.
     * It routes requests with path "/api/product" to the product service running on "http://localhost:8080".
     *
     * @return RouterFunction<ServerResponse> that defines the routing for the product service.
     */
    @Bean
    public RouterFunction<ServerResponse> productServiceRoute() {
        return GatewayRouterFunctions.route("product_service") // This route gives a name to the route for identification purposes.
                .route(RequestPredicates.path("/api/product"), HandlerFunctions.http()) // This route matches requests with path "/api/product" and forwards them to the product service running on "http://localhost:8080".
                .before(uri("http://localhost:8080"))
                // We can also use RequestPredicate.GET("/api/product") to match only GET requests with path "/api/product".
                .filter(CircuitBreakerFilterFunctions.circuitBreaker("productServiceCircuitBreaker", URI.create("forward:/fallbackRoute")))
                // or .filter(CircuitBreakerFilterFunctions.circuitBreaker("productServiceCircuitBreaker", cb -> cb.setFallbackUri("/fallbackRoute")))
                .build();
    }

    @Bean
    public RouterFunction<ServerResponse> orderServiceRoute() {
        return GatewayRouterFunctions.route("order_service")
                .route(RequestPredicates.path("/api/order"), HandlerFunctions.http())
                .before(uri("http://localhost:8081"))
                .filter(CircuitBreakerFilterFunctions.circuitBreaker("orderServiceCircuitBreaker", URI.create("forward:/fallbackRoute")))
                .build();
    }

    @Bean
    public RouterFunction<ServerResponse> inventoryServiceRoute() {
        return GatewayRouterFunctions.route("inventory_service")
                .route(RequestPredicates.path("/api/inventory"), HandlerFunctions.http())
                .before(uri("http://localhost:8082"))
                .filter(CircuitBreakerFilterFunctions.circuitBreaker("inventoryServiceCircuitBreaker", URI.create("forward:/fallbackRoute")))
                .build();
    }
    // Each bean here returns a route that spring registers with the gateway. The gateway will then use these routes to forward requests to the appropriate service based on the request path.

    @Bean
    public RouterFunction<ServerResponse> productServiceApiDocsRoute() {
        return GatewayRouterFunctions.route("product_service_api_docs")
                .route(RequestPredicates.path("/product-service/api-docs"), HandlerFunctions.http())
                .before(setPath("/api-docs"))
                .before(uri("http://localhost:8080"))
                .filter(CircuitBreakerFilterFunctions.circuitBreaker("productServiceApiDocsCircuitBreaker", URI.create("forward:/fallbackRoute")))
                .build();
    }

    @Bean
    public RouterFunction<ServerResponse> orderServiceApiDocsRoute() {
        return GatewayRouterFunctions.route("order_service_api_docs")
                .route(RequestPredicates.path("/order-service/api-docs"), HandlerFunctions.http())
                .before(setPath("/api-docs"))
                .before(uri("http://localhost:8081"))
                .filter(CircuitBreakerFilterFunctions.circuitBreaker("orderServiceApiDocsCircuitBreaker", URI.create("forward:/fallbackRoute")))
                .build();
    }

    @Bean
    public RouterFunction<ServerResponse> inventoryServiceApiDocsRoute() {
        return GatewayRouterFunctions.route("inventory_service_api_docs")
                .route(RequestPredicates.path("/inventory-service/api-docs"), HandlerFunctions.http())
                .before(setPath("/api-docs"))
                .before(uri("http://localhost:8082"))
                .filter(CircuitBreakerFilterFunctions.circuitBreaker("inventoryServiceApiDocsCircuitBreaker", URI.create("forward:/fallbackRoute")))
                .build();
    }

    @Bean
    public RouterFunction<ServerResponse> apiGatewayApiDocsRoute() {
        return GatewayRouterFunctions.route("api_gateway_api_docs")
                .route(RequestPredicates.path("/api-gateway/api-docs"), HandlerFunctions.http())
                .before(setPath("/api-docs"))
                .before(uri("http://localhost:9000"))
                .build();
    }

    @Bean
    public RouterFunction<ServerResponse> fallbackRoute() {
        return GatewayRouterFunctions.route("fallbackRoute")
                .GET("/fallbackRoute", request -> ServerResponse.status(HttpStatus.SERVICE_UNAVAILABLE).body("Service is currently unavailable. Please try again later."))
                .build();
    }
}