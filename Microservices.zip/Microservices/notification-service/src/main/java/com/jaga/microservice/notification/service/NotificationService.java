package com.jaga.microservice.notification.service;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Service;
import com.jaga.microservice.order.event.OrderPlacedEvent;

@Service
@RequiredArgsConstructor
@Slf4j
public class NotificationService {

    private final JavaMailSender javaMailSender;

    @KafkaListener(topics = "order-placed")
    public void listen(OrderPlacedEvent message) {
        log.info("Received notification message from order-placed topic: {}", message);
        MimeMessagePreparator messagePreparator = mimeMessage -> {
            MimeMessageHelper messageHelper = new MimeMessageHelper(mimeMessage);
            messageHelper.setFrom("abc@gmail.com");
            messageHelper.setTo(message.getEmail().toString());
            messageHelper.setSubject("Your order with order number %s is placed successfully".formatted(message.getOrderNumber()));
            messageHelper.setText("""
                    Hi
                    Your order with order number %s is placed successfully.
                    Best regards,
                    abc shop
                    """.formatted(message.getOrderNumber()));
        };
        try {
            javaMailSender.send(messagePreparator);
            log.info("Email notification sent successfully for order number {}", message.getOrderNumber());
        } catch (MailException e) {
            log.error("Error while sending email notification for order number {}: {}", message.getOrderNumber(), e.getMessage(), e);
            throw new RuntimeException("Error while sending email notification for order number " + message.getOrderNumber(), e);
        }
    }
}