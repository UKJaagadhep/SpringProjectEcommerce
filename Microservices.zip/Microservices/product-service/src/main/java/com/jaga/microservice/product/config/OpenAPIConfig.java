package com.jaga.microservice.product.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Info;

@Configuration
public class OpenAPIConfig {
    @Bean
    public OpenAPI productServiceAPI() {
        return new OpenAPI()
                // Besides info, we can also add externalDocs (to provide additional documentation like links), servers (to specify the base URLs for the API), tags (to group operations), security (to define security schemes), paths (to define the available endpoints), components (to define reusable schemas, parameters, responses, etc.), and more.
                .info(new Info()
                        .title("Product Service API")
                        .version("1.0")
                        .description("API documentation for the Product Service"));
        // Besides title, version and description, we can also add contact information, license information, terms of service, summary etc. to the OpenAPI object.
    }
}