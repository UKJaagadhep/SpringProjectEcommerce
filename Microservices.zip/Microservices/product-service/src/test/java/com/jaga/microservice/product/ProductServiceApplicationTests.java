package com.jaga.microservice.product;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.Import;
import org.springframework.boot.testcontainers.service.connection.ServiceConnection;
import org.testcontainers.containers.MongoDBContainer;
import io.restassured.RestAssured;
import org.hamcrest.Matchers;

@Import(TestcontainersConfiguration.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class ProductServiceApplicationTests {

	@ServiceConnection // To get the MongoDB connection details from application.properties
	static MongoDBContainer mongoDBContainer = new MongoDBContainer("mongo:7.0.5");
	@LocalServerPort // This annotation will inject the random port number into the test
	private int port;

	static {
		mongoDBContainer.start();
	}

	@BeforeEach
	void setUp() {
		RestAssured.baseURI = "http://localhost";
		RestAssured.port = port;
	}

	@Test
	void contextLoads() {
	}

	@Test
	void shouldCreateProduct() {
        String requestBody = """
				{
				    "id": "1",
			        "name": "Test Product",
			        "description": "This is a test product",
			        "price": 19.99
		        }
		        """;
		RestAssured.given()
				.header("Content-Type", "application/json") // or use .contentType("application/json")
				.body(requestBody)
				.when()
				.post("/api/product")
				.then()
				.statusCode(201)
				.body("id", Matchers.notNullValue()) // can also use .body("id", Matchers.equalTo("1")) if you want to check the exact value
		        .body("name", Matchers.equalTo("Test Product"))
				.body("description", Matchers.equalTo("This is a test product"))
				.body("price", Matchers.equalTo(19.99));
	}

}
