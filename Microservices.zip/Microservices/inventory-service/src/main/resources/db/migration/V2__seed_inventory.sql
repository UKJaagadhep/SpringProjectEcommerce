INSERT INTO inventory (sku_code, quantity)
VALUES ('iphone_13', 100),
       ('pixel_6', 50),
       ('samsung_galaxy_s21', 75),
       ('oppo_find_x3', 25),
       ('vivo_y21', 10);