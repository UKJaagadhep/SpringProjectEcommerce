package com.jaga.microservice.inventory.service;

import com.jaga.microservice.inventory.model.Inventory;
import com.jaga.microservice.inventory.repository.InventoryRepository;
import org.springframework.stereotype.Service;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class InventoryService {
    private final InventoryRepository inventoryRepository;

    public boolean isInStock(String skuCode, Integer quantity) {
        Inventory inventory = inventoryRepository.findBySkuCode(skuCode);
        return inventory != null && inventory.getQuantity() >= quantity;
    }
}