package com.jaga.microservice.inventory;

import io.restassured.RestAssured;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.context.annotation.Import;

import static org.hamcrest.Matchers.equalTo;

@Import(TestcontainersConfiguration.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class InventoryServiceApplicationTests {

	@LocalServerPort
	private int port;

	@Test
	void contextLoads() {
	}

	@Test
	void shouldReturnTrueWhenRequestedQuantityIsInStock() {
		RestAssured.given()
				.baseUri("http://localhost")
				.port(port)
				.queryParam("skuCode", "iphone_13")
				.queryParam("quantity", 100)
				.when()
				.get("/api/inventory")
				.then()
				.statusCode(200)
				.body(equalTo("true"));
	}

	@Test
	void shouldReturnFalseWhenRequestedQuantityExceedsStock() {
		RestAssured.given()
				.baseUri("http://localhost")
				.port(port)
				.queryParam("skuCode", "iphone_13")
				.queryParam("quantity", 101)
				.when()
				.get("/api/inventory")
				.then()
				.statusCode(200)
				.body(equalTo("false"));
	}

	@Test
	void shouldReturnFalseWhenSkuDoesNotExist() {
		RestAssured.given()
				.baseUri("http://localhost")
				.port(port)
				.queryParam("skuCode", "unknown")
				.queryParam("quantity", 1)
				.when()
				.get("/api/inventory")
				.then()
				.statusCode(200)
				.body(equalTo("false"));
	}
}
